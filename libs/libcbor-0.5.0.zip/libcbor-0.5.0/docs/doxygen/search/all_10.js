var searchData=
[
  ['uint16',['uint16',['../structcbor__callbacks.html#a3eb2039fa03bd534d6be0ed10d0c98be',1,'cbor_callbacks']]],
  ['uint32',['uint32',['../structcbor__callbacks.html#af2501b53c0150c4d3244a039b3232bf1',1,'cbor_callbacks']]],
  ['uint64',['uint64',['../structcbor__callbacks.html#a2b0328261726fba55f663f55f954d56b',1,'cbor_callbacks']]],
  ['uint8',['uint8',['../structcbor__callbacks.html#af2d69429c9bc71edf55b6f4f1dbb76d1',1,'cbor_callbacks']]],
  ['undefined',['undefined',['../structcbor__callbacks.html#af9b30de5bef7bf76e8e34bdd95434f98',1,'cbor_callbacks']]],
  ['unicode_2ec',['unicode.c',['../unicode_8c.html',1,'']]],
  ['unicode_2eh',['unicode.h',['../unicode_8h.html',1,'']]],
  ['utf8_5faccept',['UTF8_ACCEPT',['../unicode_8c.html#a82b09bd7c24e408c73e16db56b8db6cf',1,'unicode.c']]],
  ['utf8_5freject',['UTF8_REJECT',['../unicode_8c.html#a2e385a04dd7c4529414ab34a75a4f9ef',1,'unicode.c']]]
];
