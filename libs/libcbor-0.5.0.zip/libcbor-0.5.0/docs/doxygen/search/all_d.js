var searchData=
[
  ['read',['read',['../structcbor__load__result.html#ac5d6290cac5893bd060f6759beef2b28',1,'cbor_load_result::read()'],['../structcbor__decoder__result.html#a39828fd8d825610cda67d9738d2d5c23',1,'cbor_decoder_result::read()']]],
  ['refcount',['refcount',['../structcbor__item__t.html#a6bb24fe655f086c6aa9a66d427e09cca',1,'cbor_item_t']]],
  ['root',['root',['../struct__cbor__decoder__context.html#ad4c1540245b6241bc7aa3f7ade2fbf5a',1,'_cbor_decoder_context']]]
];
