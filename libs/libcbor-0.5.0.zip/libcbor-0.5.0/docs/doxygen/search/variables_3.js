var searchData=
[
  ['cbor_5fempty_5fcallbacks',['cbor_empty_callbacks',['../callbacks_8h.html#a3500c93f246a6c53816e52c70fe8d640',1,'callbacks.h']]],
  ['chunk_5fcapacity',['chunk_capacity',['../structcbor__indefinite__string__data.html#a4f07710bcaa663d2babf652fc9984412',1,'cbor_indefinite_string_data']]],
  ['chunk_5fcount',['chunk_count',['../structcbor__indefinite__string__data.html#a86c3abce37287c14985b5f2a0d1935d7',1,'cbor_indefinite_string_data']]],
  ['chunks',['chunks',['../structcbor__indefinite__string__data.html#ac34c0d9bd1447f53149878128e19a414',1,'cbor_indefinite_string_data']]],
  ['code',['code',['../structcbor__error.html#a8674e7cac94b696eeea37db194026646',1,'cbor_error']]],
  ['codepoint_5fcount',['codepoint_count',['../struct__cbor__string__metadata.html#a07f2e49bd1cd40ba2277ae6d7a9b6d5d',1,'_cbor_string_metadata']]],
  ['creation_5ffailed',['creation_failed',['../struct__cbor__decoder__context.html#ada14322afd080c27f3ea76b3ba657505',1,'_cbor_decoder_context']]],
  ['ctrl',['ctrl',['../struct__cbor__float__ctrl__metadata.html#aeeb531a44e6502b5f1bd2aece6dffaa2',1,'_cbor_float_ctrl_metadata']]]
];
