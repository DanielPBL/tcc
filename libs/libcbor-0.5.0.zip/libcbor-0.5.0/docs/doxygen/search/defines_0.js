var searchData=
[
  ['_5fcbor_5ffree',['_CBOR_FREE',['../common_8h.html#a1300043d7db8adf6ab67f7b787f14635',1,'common.h']]],
  ['_5fcbor_5fmalloc',['_CBOR_MALLOC',['../common_8h.html#a07a781e9212fad361b0f59f7fc921057',1,'common.h']]],
  ['_5fcbor_5frealloc',['_CBOR_REALLOC',['../common_8h.html#a1e39038d9b8e9b3a1e6529c9ff6091b8',1,'common.h']]]
];
