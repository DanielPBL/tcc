var searchData=
[
  ['uint16',['uint16',['../structcbor__callbacks.html#a3eb2039fa03bd534d6be0ed10d0c98be',1,'cbor_callbacks']]],
  ['uint32',['uint32',['../structcbor__callbacks.html#af2501b53c0150c4d3244a039b3232bf1',1,'cbor_callbacks']]],
  ['uint64',['uint64',['../structcbor__callbacks.html#a2b0328261726fba55f663f55f954d56b',1,'cbor_callbacks']]],
  ['uint8',['uint8',['../structcbor__callbacks.html#af2d69429c9bc71edf55b6f4f1dbb76d1',1,'cbor_callbacks']]],
  ['undefined',['undefined',['../structcbor__callbacks.html#af9b30de5bef7bf76e8e34bdd95434f98',1,'cbor_callbacks']]]
];
