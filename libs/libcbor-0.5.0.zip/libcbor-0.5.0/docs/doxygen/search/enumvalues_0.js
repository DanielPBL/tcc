var searchData=
[
  ['_5fcbor_5fmetadata_5fdefinite',['_CBOR_METADATA_DEFINITE',['../data_8h.html#a3cdab5e05cf46846e98b43cf77985589a051b0d1fe7ef7ccfc3824110b797429e',1,'data.h']]],
  ['_5fcbor_5fmetadata_5findefinite',['_CBOR_METADATA_INDEFINITE',['../data_8h.html#a3cdab5e05cf46846e98b43cf77985589ae598476995d503b404ccf78c21ab79ef',1,'data.h']]],
  ['_5fcbor_5funicode_5fbadcp',['_CBOR_UNICODE_BADCP',['../unicode_8h.html#a5f58283b505b6cc8a5646516ae20831fa7ddb42c4f16ebd6d46fe1e331c643c8b',1,'unicode.h']]],
  ['_5fcbor_5funicode_5fok',['_CBOR_UNICODE_OK',['../unicode_8h.html#a5f58283b505b6cc8a5646516ae20831faf42cbfe1ac853288773814920e16318c',1,'unicode.h']]]
];
