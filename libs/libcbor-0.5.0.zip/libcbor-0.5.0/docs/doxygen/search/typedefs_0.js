var searchData=
[
  ['_5fcbor_5ffree_5ft',['_cbor_free_t',['../common_8h.html#af05bb33f6d22cdac535576c8edaf208c',1,'common.h']]],
  ['_5fcbor_5fmalloc_5ft',['_cbor_malloc_t',['../common_8h.html#ad89d15c2e3f18e8914fcdffe4d725d42',1,'common.h']]],
  ['_5fcbor_5frealloc_5ft',['_cbor_realloc_t',['../common_8h.html#a5b52369a95930104d33301d12faabe75',1,'common.h']]]
];
