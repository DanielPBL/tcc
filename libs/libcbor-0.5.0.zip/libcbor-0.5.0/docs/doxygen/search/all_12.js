var searchData=
[
  ['width',['width',['../struct__cbor__int__metadata.html#a7a402d748e607c9942e5eefdb875582d',1,'_cbor_int_metadata::width()'],['../struct__cbor__float__ctrl__metadata.html#a19a1c5e96c662dd4781f0172052b194c',1,'_cbor_float_ctrl_metadata::width()']]]
];
