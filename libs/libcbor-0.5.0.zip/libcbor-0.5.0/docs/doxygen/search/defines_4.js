var searchData=
[
  ['utf8_5faccept',['UTF8_ACCEPT',['../unicode_8c.html#a82b09bd7c24e408c73e16db56b8db6cf',1,'unicode.c']]],
  ['utf8_5freject',['UTF8_REJECT',['../unicode_8c.html#a2e385a04dd7c4529414ab34a75a4f9ef',1,'unicode.c']]]
];
