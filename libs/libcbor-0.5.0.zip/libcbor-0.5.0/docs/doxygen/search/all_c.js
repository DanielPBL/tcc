var searchData=
[
  ['position',['position',['../structcbor__error.html#a6bc04669e6fff45ad7a5e22ad5826d01',1,'cbor_error']]]
];
