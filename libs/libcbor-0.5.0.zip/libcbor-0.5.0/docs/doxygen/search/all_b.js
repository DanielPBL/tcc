var searchData=
[
  ['negint16',['negint16',['../structcbor__callbacks.html#a0e47df73a7ecf894ab75e04a1cc83dc7',1,'cbor_callbacks']]],
  ['negint32',['negint32',['../structcbor__callbacks.html#a26e8c4f53af47eaaf8928b86fb92a44f',1,'cbor_callbacks']]],
  ['negint64',['negint64',['../structcbor__callbacks.html#ac0a4f4915ecb9924132c60c7fe7d93fe',1,'cbor_callbacks']]],
  ['negint8',['negint8',['../structcbor__callbacks.html#aae703108db340c2df1af0154b23b9631',1,'cbor_callbacks']]],
  ['null',['null',['../structcbor__callbacks.html#a7483f952b13db66abd893082a204859d',1,'cbor_callbacks']]]
];
