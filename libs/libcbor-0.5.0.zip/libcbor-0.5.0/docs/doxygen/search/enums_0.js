var searchData=
[
  ['_5fcbor_5fctrl',['_cbor_ctrl',['../data_8h.html#a6454b577999b479ac2585af7c204ae3b',1,'data.h']]],
  ['_5fcbor_5fdst_5fmetadata',['_cbor_dst_metadata',['../data_8h.html#a3cdab5e05cf46846e98b43cf77985589',1,'data.h']]],
  ['_5fcbor_5funicode_5fstatus_5ferror',['_cbor_unicode_status_error',['../unicode_8h.html#a5f58283b505b6cc8a5646516ae20831f',1,'unicode.h']]]
];
