var searchData=
[
  ['encoders_2ec',['encoders.c',['../encoders_8c.html',1,'']]],
  ['encoders_2eh',['encoders.h',['../encoders_8h.html',1,'']]],
  ['encoding_2ec',['encoding.c',['../encoding_8c.html',1,'']]],
  ['encoding_2eh',['encoding.h',['../encoding_8h.html',1,'']]],
  ['end_5fptr',['end_ptr',['../struct__cbor__array__metadata.html#a388742d0b665ba1775ad89858f3049cb',1,'_cbor_array_metadata::end_ptr()'],['../struct__cbor__map__metadata.html#a38136af91105ba320f1d95a4a4ceb4de',1,'_cbor_map_metadata::end_ptr()']]],
  ['error',['error',['../structcbor__load__result.html#af23777116487150fb1b06842fc57724f',1,'cbor_load_result']]]
];
