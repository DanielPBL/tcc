var searchData=
[
  ['cbor_5fdecoder_5fstatus',['cbor_decoder_status',['../data_8h.html#abfc88122444f085a1a3fee01687329fd',1,'data.h']]],
  ['cbor_5ferror_5fcode',['cbor_error_code',['../data_8h.html#a13ad43c61d917938e0ce26173e6b2eb6',1,'data.h']]],
  ['cbor_5ffloat_5fwidth',['cbor_float_width',['../data_8h.html#ac80d3ecbbdc88d96a7396ac986ee47e7',1,'data.h']]],
  ['cbor_5fint_5fwidth',['cbor_int_width',['../data_8h.html#ae0fc9740f108f0f0078b93712b061e57',1,'data.h']]],
  ['cbor_5ftype',['cbor_type',['../data_8h.html#a3a931b40fc31b51cccfd1bc3dc5fc5d6',1,'data.h']]]
];
