var searchData=
[
  ['float2',['float2',['../structcbor__callbacks.html#ab1f4ab3a5bf0cf2a6418b8cb28877652',1,'cbor_callbacks']]],
  ['float4',['float4',['../structcbor__callbacks.html#a3e0e5094fdfbc527f9a2ca300d65b7df',1,'cbor_callbacks']]],
  ['float8',['float8',['../structcbor__callbacks.html#a5a80bae7d106e7cf61d27cd710251e4a',1,'cbor_callbacks']]],
  ['float_5fctrl_5fmetadata',['float_ctrl_metadata',['../unioncbor__item__metadata.html#a456a58064b25bc6563df665bed5c122d',1,'cbor_item_metadata']]]
];
