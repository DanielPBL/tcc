var searchData=
[
  ['value',['value',['../struct__cbor__tag__metadata.html#a23bcf332e94e901e5bc3b48aab0d89da',1,'_cbor_tag_metadata::value()'],['../structcbor__pair.html#a44bbea9cc120de72fc4871a05dc8ec85',1,'cbor_pair::value()']]]
];
