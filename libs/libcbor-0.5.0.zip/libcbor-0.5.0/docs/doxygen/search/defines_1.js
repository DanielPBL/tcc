var searchData=
[
  ['cbor_5fdummy_5fcallback',['CBOR_DUMMY_CALLBACK',['../callbacks_8c.html#a600badad1d123dd9fb8d74d5f2a29a5e',1,'callbacks.c']]],
  ['cbor_5fhex_5fversion',['CBOR_HEX_VERSION',['../common_8h.html#ac61efb646fdd1936ac0ce32829f947b8',1,'common.h']]],
  ['cbor_5frestrict_5fpointer',['CBOR_RESTRICT_POINTER',['../common_8h.html#a9ac79315ed2dcf2c9587e8e3a9a6bc97',1,'common.h']]],
  ['cbor_5fversion',['CBOR_VERSION',['../common_8h.html#a956e417f98370dd1a96e4dac2e0ed7dd',1,'common.h']]],
  ['check_5fres',['CHECK_RES',['../builder__callbacks_8c.html#ac5a5fe93758a82606342a6f5513d1102',1,'builder_callbacks.c']]]
];
