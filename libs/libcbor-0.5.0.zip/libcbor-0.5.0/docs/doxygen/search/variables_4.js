var searchData=
[
  ['data',['data',['../structcbor__item__t.html#a5c6dde1dbef5aad748c49786352eef44',1,'cbor_item_t']]]
];
