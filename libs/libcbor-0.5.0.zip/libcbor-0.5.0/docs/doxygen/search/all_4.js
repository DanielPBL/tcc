var searchData=
[
  ['data',['data',['../structcbor__item__t.html#a5c6dde1dbef5aad748c49786352eef44',1,'cbor_item_t']]],
  ['data_2eh',['data.h',['../data_8h.html',1,'']]],
  ['debug_5fprint',['debug_print',['../common_8h.html#a7377cc956f5c81538f0fbf0a0492a539',1,'common.h']]],
  ['doxy_5ffrontpage_2emd',['doxy_frontpage.md',['../doxy__frontpage_8md.html',1,'']]]
];
