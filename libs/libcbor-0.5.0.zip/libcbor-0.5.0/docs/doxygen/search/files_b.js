var searchData=
[
  ['unicode_2ec',['unicode.c',['../unicode_8c.html',1,'']]],
  ['unicode_2eh',['unicode.h',['../unicode_8h.html',1,'']]]
];
